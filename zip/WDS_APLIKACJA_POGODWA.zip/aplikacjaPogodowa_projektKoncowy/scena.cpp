#include "scena.h"

Scena::Scena(QObject *parent) : QGraphicsScene(parent)
{

}
