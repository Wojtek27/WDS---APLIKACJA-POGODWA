var class_miasto =
[
    [ "Miasto", "class_miasto.html#a743bc4ad37bc437620470d626cfcced5", null ],
    [ "~Miasto", "class_miasto.html#af1f9046a39f7ba4c8c08eb07dfd89bbd", null ],
    [ "ui", "class_miasto.html#a7d9dadc2af6d6b003ee1f94ed5c19ac0", null ]
];