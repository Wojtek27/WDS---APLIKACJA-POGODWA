var searchData=
[
  ['manager_216',['manager',['../classdrugie_okno.html#a8efe34c26404389000c59ba1d1dad332',1,'drugieOkno']]],
  ['miastopl_217',['miastoPl',['../classdrugie_okno.html#ab9e0f35b41176bcc53f93aa91b31247c',1,'drugieOkno']]],
  ['mocnezach_218',['mocneZach',['../classdrugie_okno.html#a7d0b0c0605310d1aa1314818e3bab67d',1,'drugieOkno']]]
];
