var searchData=
[
  ['zachmurzenie_117',['zachmurzenie',['../classdrugie_okno.html#a1ed2cf3e34d488ea5abe46383ceab222',1,'drugieOkno']]],
  ['zegar_118',['zegar',['../classdrugie_okno.html#aff018ff12513a1ab2205c2b89e63268a',1,'drugieOkno::zegar()'],['../class_main_window.html#a41c706c4aa6bb1bae9b1978009630978',1,'MainWindow::zegar()']]],
  ['zielonagora_119',['zielonaGora',['../class_main_window.html#a3a53c0bbdd1e9fff0f9281264e1b56f0',1,'MainWindow']]]
];
