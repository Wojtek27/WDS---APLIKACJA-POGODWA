var searchData=
[
  ['deszcz_204',['deszcz',['../classdrugie_okno.html#af2a495a0477d32e1cbbab76022ba32cd',1,'drugieOkno']]],
  ['drugieokno_205',['drugieokno',['../class_main_window.html#abf409f6d9f1ffd903afad8cb04c7430b',1,'MainWindow']]]
];
