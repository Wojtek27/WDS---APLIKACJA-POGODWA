var searchData=
[
  ['pogoda_86',['pogoda',['../classdrugie_okno.html#adc513343841e92e96629cde1ed0007d7',1,'drugieOkno']]],
  ['potrzebneparametry_87',['potrzebneParametry',['../classdrugie_okno.html#aef3a2d4050643a02df95df74eeeac968',1,'drugieOkno']]],
  ['poznan_88',['poznan',['../class_main_window.html#a043d5f8bb65a603035ec4172ba623cf0',1,'MainWindow']]]
];
