var searchData=
[
  ['burza_202',['burza',['../classdrugie_okno.html#a0f90f59ed869c78da4bac8ad10a998b6',1,'drugieOkno']]],
  ['bydgoszcz_203',['bydgoszcz',['../class_main_window.html#ae19cf2ab04fb9d2ca56058b84fafc44c',1,'MainWindow']]]
];
