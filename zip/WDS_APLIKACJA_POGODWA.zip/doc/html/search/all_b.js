var searchData=
[
  ['ui_110',['Ui',['../namespace_ui.html',1,'']]],
  ['ui_111',['ui',['../classdrugie_okno.html#a7ffd1255b53f9e340829d64016eab304',1,'drugieOkno::ui()'],['../class_main_window.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()']]],
  ['ustawparametry_112',['ustawParametry',['../classdrugie_okno.html#aaffecb90f360efdf86750312fd056da3',1,'drugieOkno']]]
];
