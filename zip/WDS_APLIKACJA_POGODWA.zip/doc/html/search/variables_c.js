var searchData=
[
  ['warszawa_242',['warszawa',['../class_main_window.html#a2101000e72ddf25ad9b3755a08eb5455',1,'MainWindow']]],
  ['wroclaw_243',['wroclaw',['../class_main_window.html#a288be1eff84f162b22b1e6828b5eed91',1,'MainWindow']]]
];
