var searchData=
[
  ['gdansk_206',['gdansk',['../class_main_window.html#a0ec87d85418dea0111271a05cafc4de8',1,'MainWindow']]],
  ['gorzowwielkopolski_207',['gorzowWielkopolski',['../class_main_window.html#ae70790c31525c1c19313b8a9bc40ec9e',1,'MainWindow']]]
];
