var searchData=
[
  ['ustawparametry_197',['ustawParametry',['../classdrugie_okno.html#aaffecb90f360efdf86750312fd056da3',1,'drugieOkno']]]
];
