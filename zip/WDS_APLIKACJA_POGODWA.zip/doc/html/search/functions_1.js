var searchData=
[
  ['godzina_134',['godzina',['../classdrugie_okno.html#a5efc5bb537b0063b6d294b2e457a4c0a',1,'drugieOkno::godzina()'],['../class_main_window.html#a3f05dccfa1f70ba0cbffeabdc216f70c',1,'MainWindow::godzina()']]]
];
