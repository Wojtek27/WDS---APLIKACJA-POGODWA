var searchData=
[
  ['lekkideszcz_14',['lekkiDeszcz',['../classdrugie_okno.html#a5ed137f088eaff8433dbdae62424005d',1,'drugieOkno']]],
  ['lekkiezach_15',['lekkieZach',['../classdrugie_okno.html#a43ace4b5d2b08518e5b76c0f77b7d1a8',1,'drugieOkno']]],
  ['lodz_16',['lodz',['../class_main_window.html#a183ed824bb58318d81fd71b1d5bd820f',1,'MainWindow']]],
  ['lublin_17',['lublin',['../class_main_window.html#ae854c893d74abd7c8d26e7ce2e40ad21',1,'MainWindow']]]
];
