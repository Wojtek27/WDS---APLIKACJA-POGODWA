var searchData=
[
  ['olsztyn_219',['olsztyn',['../class_main_window.html#a1213ae2d9c94899da5eaa75ab76b9f06',1,'MainWindow']]],
  ['opole_220',['opole',['../class_main_window.html#a44faa954d540664d82dc6584c8244285',1,'MainWindow']]]
];
