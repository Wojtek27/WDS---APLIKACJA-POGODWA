var searchData=
[
  ['pogoda_221',['pogoda',['../classdrugie_okno.html#adc513343841e92e96629cde1ed0007d7',1,'drugieOkno']]],
  ['poznan_222',['poznan',['../class_main_window.html#a043d5f8bb65a603035ec4172ba623cf0',1,'MainWindow']]]
];
