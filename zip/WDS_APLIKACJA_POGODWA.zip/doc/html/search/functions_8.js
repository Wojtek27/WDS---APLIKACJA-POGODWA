var searchData=
[
  ['_7edrugieokno_200',['~drugieOkno',['../classdrugie_okno.html#aa2b938b1e62f3c3f8c582bf987c4923a',1,'drugieOkno']]],
  ['_7emainwindow_201',['~MainWindow',['../class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]]
];
