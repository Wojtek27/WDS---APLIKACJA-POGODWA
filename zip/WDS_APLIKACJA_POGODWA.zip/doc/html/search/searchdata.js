var indexSectionsWithContent =
{
  0: "bdgklmoprstuwz~",
  1: "dms",
  2: "u",
  3: "dms",
  4: "dgmopsuw~",
  5: "bdgklmoprstuwz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne"
};

