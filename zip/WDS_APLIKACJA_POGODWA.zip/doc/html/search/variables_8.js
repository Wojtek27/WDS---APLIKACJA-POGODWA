var searchData=
[
  ['rzeszow_223',['rzeszow',['../class_main_window.html#ac68bc7dfdf150bc62b7f3d504144c65c',1,'MainWindow']]]
];
