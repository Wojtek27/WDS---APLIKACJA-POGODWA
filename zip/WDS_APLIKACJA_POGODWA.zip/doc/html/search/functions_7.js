var searchData=
[
  ['wez_198',['wez',['../classdrugie_okno.html#ae68529b87ceb7cccd2ef5bdd9213b2b0',1,'drugieOkno']]],
  ['wyluskajjsona_199',['wyluskajJsona',['../classdrugie_okno.html#a988f53600968656ad40cacf2c49de4eb',1,'drugieOkno']]]
];
