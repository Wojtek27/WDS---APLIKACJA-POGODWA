var searchData=
[
  ['potrzebneparametry_195',['potrzebneParametry',['../classdrugie_okno.html#aef3a2d4050643a02df95df74eeeac968',1,'drugieOkno']]]
];
