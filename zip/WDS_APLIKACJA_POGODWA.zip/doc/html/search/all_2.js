var searchData=
[
  ['gdansk_7',['gdansk',['../class_main_window.html#a0ec87d85418dea0111271a05cafc4de8',1,'MainWindow']]],
  ['godzina_8',['godzina',['../classdrugie_okno.html#a5efc5bb537b0063b6d294b2e457a4c0a',1,'drugieOkno::godzina()'],['../class_main_window.html#a3f05dccfa1f70ba0cbffeabdc216f70c',1,'MainWindow::godzina()']]],
  ['gorzowwielkopolski_9',['gorzowWielkopolski',['../class_main_window.html#ae70790c31525c1c19313b8a9bc40ec9e',1,'MainWindow']]]
];
