var hierarchy =
[
    [ "QDialog", null, [
      [ "drugieOkno", "classdrugie_okno.html", null ]
    ] ],
    [ "QGraphicsScene", null, [
      [ "Scena", "class_scena.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ]
];