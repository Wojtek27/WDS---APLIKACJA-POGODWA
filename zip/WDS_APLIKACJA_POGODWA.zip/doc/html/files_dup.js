var files_dup =
[
    [ "drugieokno.cpp", "drugieokno_8cpp.html", null ],
    [ "drugieokno.h", "drugieokno_8h.html", [
      [ "drugieOkno", "classdrugie_okno.html", "classdrugie_okno" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "scena.cpp", "scena_8cpp.html", null ],
    [ "scena.h", "scena_8h.html", [
      [ "Scena", "class_scena.html", "class_scena" ]
    ] ]
];