var classpobieranie_danych =
[
    [ "pobieranieDanych", "classpobieranie_danych.html#a98bc2a6aba61d34af887f74bbdaf9274", null ],
    [ "onRequestCompleted", "classpobieranie_danych.html#ad1bed9d5fab2a2c9fb21915302c54fdc", null ],
    [ "ReadInternetPage", "classpobieranie_danych.html#aa1258772b0f9bf539433de11dfe61c9d", null ],
    [ "mNetworkManager", "classpobieranie_danych.html#af3413c9445cdcc72ae7ef874354eb55c", null ]
];