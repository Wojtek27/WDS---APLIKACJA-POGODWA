var annotated_dup =
[
    [ "drugieOkno", "classdrugie_okno.html", "classdrugie_okno" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Scena", "class_scena.html", "class_scena" ]
];