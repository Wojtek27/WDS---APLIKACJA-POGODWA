var dir_5a3d4f7660ed222d2a7e7d7f4623c1cb =
[
    [ "drugieokno.cpp", "drugieokno_8cpp.html", null ],
    [ "drugieokno.h", "drugieokno_8h.html", [
      [ "drugieOkno", "classdrugie_okno.html", "classdrugie_okno" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "miasto.cpp", "miasto_8cpp.html", null ],
    [ "miasto.h", "miasto_8h.html", [
      [ "Miasto", "class_miasto.html", "class_miasto" ]
    ] ],
    [ "pobieraniedanych.cpp", "pobieraniedanych_8cpp.html", null ],
    [ "pobieraniedanych.h", "pobieraniedanych_8h.html", [
      [ "pobieranieDanych", "classpobieranie_danych.html", "classpobieranie_danych" ]
    ] ],
    [ "scena.cpp", "scena_8cpp.html", null ],
    [ "scena.h", "scena_8h.html", [
      [ "Scena", "class_scena.html", "class_scena" ]
    ] ]
];